# KreFolio v1
Onepage, Responsive Bootstrap template. Have a look at [Demo](http://shapebootstrap.net/preview/?id=1394) hosted at [ShapeBootstrap](http://shapebootstrap.net/).

## Instructions
    - Customize as your need.
    - Upload to a web server via ftp.

## Twitter setup
Go to [Twitter Widgets](https://twitter.com/settings/widgets)

    - Click on "Create new"
    - Enter your credentials there
    - Click on "Create Widget"
    - Now at the bottom of the page you will get some code in a textarea.
    - Look for "data-widget-id" inside the textarea. 
    - Copy the "data-widget-id".
    - Open "main.js" file of the package.
    - Go to "Grab last tweet section"
    - on the "id" property input your "data-widget-id" inside ''

## Color variation usage
All color variation has different html and different css file. So, just rename your desired color variation to index.html and your are good to go.

## Contact me:
If you like my work and to want to work with me, please contact via [Twitter](https://twitter.com/ch0yan) or [Mail](mailto:choyan.009@gmail.com).
